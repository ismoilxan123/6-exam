import { Link } from "react-router-dom";

const PlayAgain = () => {
  return (
    <div>
      <Link to={"/"}>
        <button>Play Again</button>
      </Link>
    </div>
  );
};

export default PlayAgain;
